"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  ArrowLeft,
  Plus,
  Trash2,
  Save,
  Play,
  Users,
  MessageCircle,
  Clock,
  CheckCircle2,
  AlertCircle,
  Send,
  X,
  Minimize2,
  Maximize2,
  Edit3,
  Eye,
  Share2,
} from "lucide-react"

interface Question {
  id: string
  question: string
  type: "multiple-choice" | "true-false" | "short-answer"
  options?: string[]
  correct?: number | string
  explanation?: string
  difficulty: "easy" | "medium" | "hard"
  points: number
}

interface Collaborator {
  id: string
  name: string
  email: string
  avatar: string
  role: "owner" | "editor" | "viewer"
  status: "online" | "offline"
  lastSeen: Date
  cursor?: { x: number; y: number; color: string }
}

interface Comment {
  id: string
  text: string
  author: Collaborator
  questionId?: string
  timestamp: Date
  resolved: boolean
}

interface Activity {
  id: string
  type: "edit" | "comment" | "join" | "leave"
  user: Collaborator
  timestamp: Date
  description: string
}

export default function CreateQuizPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("details")
  const [collaborationOpen, setCollaborationOpen] = useState(false)
  const [collaborationTab, setCollaborationTab] = useState<"collaborators" | "comments" | "activity">("collaborators")
  const [isMinimized, setIsMinimized] = useState(false)
  const [newComment, setNewComment] = useState("")

  // Quiz state
  const [quiz, setQuiz] = useState({
    title: "",
    subject: "",
    topic: "",
    difficulty: "medium" as const,
    timeLimit: 30,
    description: "",
    isPublic: false,
    allowRetakes: true,
    showCorrectAnswers: true,
    randomizeQuestions: false,
  })

  const [questions, setQuestions] = useState<Question[]>([])
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null)

  // Collaboration state
  const [collaborators] = useState<Collaborator[]>([
    {
      id: "1",
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@school.edu",
      avatar: "SJ",
      role: "owner",
      status: "online",
      lastSeen: new Date(),
      cursor: { x: 150, y: 200, color: "#3B82F6" },
    },
    {
      id: "2",
      name: "Prof. Michael Chen",
      email: "m.chen@school.edu",
      avatar: "MC",
      role: "editor",
      status: "online",
      lastSeen: new Date(),
      cursor: { x: 300, y: 150, color: "#10B981" },
    },
    {
      id: "3",
      name: "Dr. Emily Rodriguez",
      email: "e.rodriguez@school.edu",
      avatar: "ER",
      role: "editor",
      status: "offline",
      lastSeen: new Date(Date.now() - 2 * 60 * 60 * 1000),
    },
  ])

  const [comments, setComments] = useState<Comment[]>([
    {
      id: "1",
      text: "Should we make this question more challenging?",
      author: collaborators[1],
      questionId: "q1",
      timestamp: new Date(Date.now() - 10 * 60 * 1000),
      resolved: false,
    },
    {
      id: "2",
      text: "The explanation could be clearer here.",
      author: collaborators[0],
      questionId: "q2",
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      resolved: false,
    },
  ])

  const [activities] = useState<Activity[]>([
    {
      id: "1",
      type: "edit",
      user: collaborators[1],
      timestamp: new Date(Date.now() - 2 * 60 * 1000),
      description: "edited Question 3",
    },
    {
      id: "2",
      type: "comment",
      user: collaborators[0],
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      description: "commented on Question 2",
    },
    {
      id: "3",
      type: "join",
      user: collaborators[1],
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      description: "joined the collaboration",
    },
  ])

  const currentUser = collaborators[0]
  const onlineCollaborators = collaborators.filter((c) => c.status === "online")
  const unresolvedComments = comments.filter((c) => !c.resolved)

  const addQuestion = () => {
    const newQuestion: Question = {
      id: Math.random().toString(36).substr(2, 9),
      question: "",
      type: "multiple-choice",
      options: ["", "", "", ""],
      correct: 0,
      explanation: "",
      difficulty: "medium",
      points: 1,
    }
    setQuestions([...questions, newQuestion])
    setEditingQuestion(newQuestion)
  }

  const updateQuestion = (questionId: string, updates: Partial<Question>) => {
    setQuestions(questions.map((q) => (q.id === questionId ? { ...q, ...updates } : q)))
    if (editingQuestion?.id === questionId) {
      setEditingQuestion({ ...editingQuestion, ...updates })
    }
  }

  const deleteQuestion = (questionId: string) => {
    setQuestions(questions.filter((q) => q.id !== questionId))
    if (editingQuestion?.id === questionId) {
      setEditingQuestion(null)
    }
  }

  const handleAddComment = (text: string, questionId?: string) => {
    const newCommentObj: Comment = {
      id: Math.random().toString(36).substr(2, 9),
      text,
      author: currentUser,
      questionId,
      timestamp: new Date(),
      resolved: false,
    }
    setComments([newCommentObj, ...comments])
  }

  const handleResolveComment = (commentId: string) => {
    setComments(comments.map((comment) => (comment.id === commentId ? { ...comment, resolved: true } : comment)))
  }

  const saveQuiz = async () => {
    // Simulate saving
    console.log("Saving quiz:", { quiz, questions })
  }

  const publishQuiz = async () => {
    // Simulate publishing
    console.log("Publishing quiz:", { quiz, questions })
  }

  // Live editing indicators
  const LiveEditingIndicator = ({ questionId }: { questionId?: string }) => {
    const [editingUsers, setEditingUsers] = useState<
      Array<{
        id: string
        name: string
        avatar: string
        color: string
        action: "editing" | "viewing"
      }>
    >([])

    useEffect(() => {
      const activeUsers = collaborators
        .filter((c) => c.status === "online" && c.id !== currentUser.id)
        .map((c) => ({
          id: c.id,
          name: c.name,
          avatar: c.avatar,
          color: c.cursor?.color || "#3B82F6",
          action: Math.random() > 0.7 ? ("editing" as const) : ("viewing" as const),
        }))

      setEditingUsers(activeUsers)

      const interval = setInterval(() => {
        const updatedUsers = activeUsers.map((user) => ({
          ...user,
          action: Math.random() > 0.6 ? ("editing" as const) : ("viewing" as const),
        }))
        setEditingUsers(updatedUsers)
      }, 2000)

      return () => clearInterval(interval)
    }, [questionId])

    const editingCount = editingUsers.filter((u) => u.action === "editing").length
    const viewingCount = editingUsers.filter((u) => u.action === "viewing").length

    if (editingUsers.length === 0) return null

    return (
      <div className="flex items-center space-x-2">
        {editingCount > 0 && (
          <div className="flex items-center space-x-1">
            <div className="flex -space-x-1">
              {editingUsers
                .filter((u) => u.action === "editing")
                .slice(0, 3)
                .map((user) => (
                  <div key={user.id} className="relative">
                    <Avatar className="w-6 h-6 border-2 border-white">
                      <AvatarFallback className="text-xs text-white" style={{ backgroundColor: user.color }}>
                        {user.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-orange-500 rounded-full border border-white flex items-center justify-center">
                      <Edit3 className="w-2 h-2 text-white" />
                    </div>
                  </div>
                ))}
            </div>
            <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">
              <Edit3 className="w-3 h-3 mr-1" />
              {editingCount} editing
            </Badge>
          </div>
        )}

        {viewingCount > 0 && (
          <Badge variant="outline" className="text-xs">
            <Eye className="w-3 h-3 mr-1" />
            {viewingCount} viewing
          </Badge>
        )}
      </div>
    )
  }

  // Collaboration Sidebar Component
  const CollaborationSidebar = () => {
    if (!collaborationOpen) return null

    return (
      <div
        className={`fixed right-0 top-0 h-full bg-white border-l border-gray-200 shadow-xl z-50 transition-all duration-300 ${
          isMinimized ? "w-16" : "w-80"
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-emerald-50 to-teal-50">
          {!isMinimized && (
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-emerald-600" />
              <span className="font-semibold text-gray-800">Collaboration</span>
            </div>
          )}
          <div className="flex items-center space-x-1">
            <Button
              onClick={() => setIsMinimized(!isMinimized)}
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:bg-gray-100"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
            <Button
              onClick={() => setCollaborationOpen(false)}
              variant="ghost"
              size="sm"
              className="text-gray-600 hover:bg-gray-100"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Tab Navigation */}
            <div className="flex border-b">
              <button
                onClick={() => setCollaborationTab("collaborators")}
                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
                  collaborationTab === "collaborators"
                    ? "text-emerald-600 border-b-2 border-emerald-600 bg-emerald-50"
                    : "text-gray-600 hover:text-gray-800"
                }`}
              >
                <div className="flex items-center justify-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span>{onlineCollaborators.length}</span>
                </div>
              </button>
              <button
                onClick={() => setCollaborationTab("comments")}
                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors relative ${
                  collaborationTab === "comments"
                    ? "text-emerald-600 border-b-2 border-emerald-600 bg-emerald-50"
                    : "text-gray-600 hover:text-gray-800"
                }`}
              >
                <div className="flex items-center justify-center space-x-1">
                  <MessageCircle className="w-4 h-4" />
                  <span>{unresolvedComments.length}</span>
                </div>
                {unresolvedComments.length > 0 && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />
                )}
              </button>
              <button
                onClick={() => setCollaborationTab("activity")}
                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
                  collaborationTab === "activity"
                    ? "text-emerald-600 border-b-2 border-emerald-600 bg-emerald-50"
                    : "text-gray-600 hover:text-gray-800"
                }`}
              >
                <Clock className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden">
              {collaborationTab === "collaborators" && (
                <ScrollArea className="h-full p-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-800 mb-3">Online ({onlineCollaborators.length})</h3>
                      <div className="space-y-3">
                        {onlineCollaborators.map((collaborator) => (
                          <div key={collaborator.id} className="flex items-center space-x-3">
                            <div className="relative">
                              <Avatar className="w-8 h-8">
                                <AvatarFallback className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs">
                                  {collaborator.avatar}
                                </AvatarFallback>
                              </Avatar>
                              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {collaborator.name}
                                {collaborator.id === currentUser.id && " (You)"}
                              </p>
                              <div className="flex items-center space-x-2">
                                <Badge
                                  variant={collaborator.role === "owner" ? "default" : "secondary"}
                                  className="text-xs"
                                >
                                  {collaborator.role}
                                </Badge>
                                {collaborator.cursor && (
                                  <div className="flex items-center space-x-1">
                                    <div
                                      className="w-2 h-2 rounded-full"
                                      style={{ backgroundColor: collaborator.cursor.color }}
                                    />
                                    <span className="text-xs text-gray-500">Editing</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {collaborators.filter((c) => c.status === "offline").length > 0 && (
                      <>
                        <Separator />
                        <div>
                          <h3 className="text-sm font-medium text-gray-800 mb-3">
                            Offline ({collaborators.filter((c) => c.status === "offline").length})
                          </h3>
                          <div className="space-y-3">
                            {collaborators
                              .filter((c) => c.status === "offline")
                              .map((collaborator) => (
                                <div key={collaborator.id} className="flex items-center space-x-3 opacity-60">
                                  <Avatar className="w-8 h-8">
                                    <AvatarFallback className="bg-gray-400 text-white text-xs">
                                      {collaborator.avatar}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-gray-700 truncate">{collaborator.name}</p>
                                    <div className="flex items-center space-x-2">
                                      <Badge variant="secondary" className="text-xs">
                                        {collaborator.role}
                                      </Badge>
                                      <span className="text-xs text-gray-500">
                                        Last seen {collaborator.lastSeen.toLocaleDateString()}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              ))}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </ScrollArea>
              )}

              {collaborationTab === "comments" && (
                <div className="h-full flex flex-col">
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {comments.length === 0 ? (
                        <div className="text-center py-8">
                          <MessageCircle className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-600">No comments yet</p>
                        </div>
                      ) : (
                        comments.map((comment) => (
                          <div
                            key={comment.id}
                            className={`p-3 rounded-lg border ${
                              comment.resolved ? "bg-gray-50 border-gray-200" : "bg-white border-gray-300"
                            }`}
                          >
                            <div className="flex items-start space-x-2">
                              <Avatar className="w-6 h-6">
                                <AvatarFallback className="bg-emerald-600 text-white text-xs">
                                  {comment.author.avatar}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2 mb-1">
                                  <span className="text-sm font-medium text-gray-900">{comment.author.name}</span>
                                  <span className="text-xs text-gray-500">
                                    {comment.timestamp.toLocaleTimeString()}
                                  </span>
                                </div>
                                <p className="text-sm text-gray-700 mb-2">{comment.text}</p>
                                <div className="flex items-center space-x-2">
                                  {comment.questionId && (
                                    <Badge variant="outline" className="text-xs">
                                      Q{comment.questionId}
                                    </Badge>
                                  )}
                                  {!comment.resolved && (
                                    <Button
                                      onClick={() => handleResolveComment(comment.id)}
                                      size="sm"
                                      variant="ghost"
                                      className="text-xs text-green-600 hover:bg-green-50 p-1 h-auto"
                                    >
                                      <CheckCircle2 className="w-3 h-3 mr-1" />
                                      Resolve
                                    </Button>
                                  )}
                                  {comment.resolved && (
                                    <div className="flex items-center space-x-1 text-green-600">
                                      <CheckCircle2 className="w-3 h-3" />
                                      <span className="text-xs">Resolved</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>

                  {/* Add Comment */}
                  <div className="p-4 border-t bg-gray-50">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Add a comment..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === "Enter") {
                            if (newComment.trim()) {
                              handleAddComment(newComment)
                              setNewComment("")
                            }
                          }
                        }}
                        className="text-sm"
                      />
                      <Button
                        onClick={() => {
                          if (newComment.trim()) {
                            handleAddComment(newComment)
                            setNewComment("")
                          }
                        }}
                        disabled={!newComment.trim()}
                        size="sm"
                        className="bg-emerald-600 hover:bg-emerald-700"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {collaborationTab === "activity" && (
                <ScrollArea className="h-full p-4">
                  <div className="space-y-4">
                    {activities.length === 0 ? (
                      <div className="text-center py-8">
                        <Clock className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">No recent activity</p>
                      </div>
                    ) : (
                      activities.map((activity) => (
                        <div key={activity.id} className="flex items-start space-x-3">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="bg-blue-600 text-white text-xs">
                              {activity.user.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-gray-900">
                              <span className="font-medium">{activity.user.name}</span> {activity.description}
                            </p>
                            <p className="text-xs text-gray-500">{activity.timestamp.toLocaleString()}</p>
                          </div>
                          <div className="flex-shrink-0">
                            {activity.type === "edit" && <AlertCircle className="w-4 h-4 text-orange-500" />}
                            {activity.type === "comment" && <MessageCircle className="w-4 h-4 text-blue-500" />}
                            {activity.type === "join" && <Users className="w-4 h-4 text-green-500" />}
                            {activity.type === "leave" && <Users className="w-4 h-4 text-red-500" />}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              )}
            </div>
          </>
        )}

        {/* Minimized State */}
        {isMinimized && (
          <div className="p-2 space-y-2">
            <div className="flex flex-col items-center space-y-1">
              <div className="relative">
                <Users className="w-6 h-6 text-emerald-600" />
                {onlineCollaborators.length > 0 && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full text-xs text-white flex items-center justify-center">
                    {onlineCollaborators.length}
                  </div>
                )}
              </div>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <div className="relative">
                <MessageCircle className="w-6 h-6 text-blue-600" />
                {unresolvedComments.length > 0 && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                    {unresolvedComments.length}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-30">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => router.back()}
                className="border-emerald-200 text-emerald-600 hover:bg-emerald-50"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-800">Create Quiz</h1>
                <p className="text-sm text-gray-600">Build engaging quizzes for your students</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {/* Live collaboration indicators */}
              <div className="flex items-center space-x-2">
                <div className="flex -space-x-2">
                  {onlineCollaborators.slice(0, 3).map((collaborator) => (
                    <Avatar key={collaborator.id} className="w-8 h-8 border-2 border-white">
                      <AvatarFallback className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs">
                        {collaborator.avatar}
                      </AvatarFallback>
                    </Avatar>
                  ))}
                </div>
                <span className="text-sm text-gray-600">{onlineCollaborators.length} online</span>
              </div>

              <Button
                onClick={() => setCollaborationOpen(!collaborationOpen)}
                variant="outline"
                className="border-blue-200 text-blue-600 hover:bg-blue-50"
              >
                <Users className="w-4 h-4 mr-2" />
                Collaborate
              </Button>

              <Button variant="outline" className="border-purple-200 text-purple-600 hover:bg-purple-50 bg-transparent">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>

              <Button
                onClick={saveQuiz}
                variant="outline"
                className="border-emerald-200 text-emerald-600 hover:bg-emerald-50 bg-transparent"
              >
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>

              <Button
                onClick={publishQuiz}
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              >
                <Play className="w-4 h-4 mr-2" />
                Publish
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className={`transition-all duration-300 ${collaborationOpen ? "mr-80" : "mr-0"}`}>
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Collaboration Status */}
            {collaborationOpen && (
              <Card className="mb-6 border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" />
                        <span className="text-sm font-medium text-gray-800">Collaborative Editing</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span>Last saved: {new Date().toLocaleTimeString()}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <LiveEditingIndicator />
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                        Draft
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-3 bg-white border border-gray-200">
                <TabsTrigger
                  value="details"
                  className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-600"
                >
                  Quiz Details
                </TabsTrigger>
                <TabsTrigger
                  value="questions"
                  className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-600"
                >
                  Questions ({questions.length})
                </TabsTrigger>
                <TabsTrigger
                  value="settings"
                  className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-600"
                >
                  Settings
                </TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-6">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Basic Information
                      <LiveEditingIndicator questionId="details" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="title">Quiz Title</Label>
                        <Input
                          id="title"
                          placeholder="Enter quiz title..."
                          value={quiz.title}
                          onChange={(e) => setQuiz({ ...quiz, title: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="subject">Subject</Label>
                        <Select value={quiz.subject} onValueChange={(value) => setQuiz({ ...quiz, subject: value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select subject" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mathematics">Mathematics</SelectItem>
                            <SelectItem value="science">Science</SelectItem>
                            <SelectItem value="english">English</SelectItem>
                            <SelectItem value="history">History</SelectItem>
                            <SelectItem value="geography">Geography</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="topic">Topic</Label>
                        <Input
                          id="topic"
                          placeholder="Enter topic..."
                          value={quiz.topic}
                          onChange={(e) => setQuiz({ ...quiz, topic: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="difficulty">Difficulty</Label>
                        <Select
                          value={quiz.difficulty}
                          onValueChange={(value: any) => setQuiz({ ...quiz, difficulty: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="easy">Easy</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="hard">Hard</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        placeholder="Enter quiz description..."
                        value={quiz.description}
                        onChange={(e) => setQuiz({ ...quiz, description: e.target.value })}
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="questions" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-800">Questions</h2>
                  <Button onClick={addQuestion} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Question
                  </Button>
                </div>

                {questions.length === 0 ? (
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-12 text-center">
                      <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Plus className="w-8 h-8 text-emerald-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-800 mb-2">No questions yet</h3>
                      <p className="text-gray-600 mb-4">Start building your quiz by adding your first question.</p>
                      <Button onClick={addQuestion} className="bg-emerald-600 hover:bg-emerald-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add First Question
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <Card key={question.id} className="border-0 shadow-lg">
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg">Question {index + 1}</CardTitle>
                            <div className="flex items-center space-x-2">
                              <LiveEditingIndicator questionId={question.id} />
                              <Badge variant="outline" className="capitalize">
                                {question.type.replace("-", " ")}
                              </Badge>
                              <Button
                                onClick={() => deleteQuestion(question.id)}
                                variant="ghost"
                                size="sm"
                                className="text-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <Label>Question</Label>
                            <Textarea
                              placeholder="Enter your question..."
                              value={question.question}
                              onChange={(e) => updateQuestion(question.id, { question: e.target.value })}
                              rows={2}
                            />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                              <Label>Type</Label>
                              <Select
                                value={question.type}
                                onChange={(value: any) => updateQuestion(question.id, { type: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="multiple-choice">Multiple Choice</SelectItem>
                                  <SelectItem value="true-false">True/False</SelectItem>
                                  <SelectItem value="short-answer">Short Answer</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Difficulty</Label>
                              <Select
                                value={question.difficulty}
                                onChange={(value: any) => updateQuestion(question.id, { difficulty: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="easy">Easy</SelectItem>
                                  <SelectItem value="medium">Medium</SelectItem>
                                  <SelectItem value="hard">Hard</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Points</Label>
                              <Input
                                type="number"
                                min="1"
                                value={question.points}
                                onChange={(e) =>
                                  updateQuestion(question.id, { points: Number.parseInt(e.target.value) || 1 })
                                }
                              />
                            </div>
                          </div>

                          {question.type === "multiple-choice" && (
                            <div className="space-y-2">
                              <Label>Answer Options</Label>
                              <div className="space-y-2">
                                {question.options?.map((option, optionIndex) => (
                                  <div key={optionIndex} className="flex items-center space-x-2">
                                    <input
                                      type="radio"
                                      name={`correct-${question.id}`}
                                      checked={question.correct === optionIndex}
                                      onChange={() => updateQuestion(question.id, { correct: optionIndex })}
                                      className="text-emerald-600"
                                    />
                                    <Input
                                      placeholder={`Option ${String.fromCharCode(65 + optionIndex)}`}
                                      value={option}
                                      onChange={(e) => {
                                        const newOptions = [...(question.options || [])]
                                        newOptions[optionIndex] = e.target.value
                                        updateQuestion(question.id, { options: newOptions })
                                      }}
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {question.type === "true-false" && (
                            <div className="space-y-2">
                              <Label>Correct Answer</Label>
                              <Select
                                value={question.correct?.toString()}
                                onChange={(value) => updateQuestion(question.id, { correct: value === "true" })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="true">True</SelectItem>
                                  <SelectItem value="false">False</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          )}

                          <div className="space-y-2">
                            <Label>Explanation (Optional)</Label>
                            <Textarea
                              placeholder="Explain the correct answer..."
                              value={question.explanation || ""}
                              onChange={(e) => updateQuestion(question.id, { explanation: e.target.value })}
                              rows={2}
                            />
                          </div>

                          {/* Question-specific comments */}
                          {comments.filter((c) => c.questionId === question.id).length > 0 && (
                            <div className="border-t pt-4">
                              <h4 className="font-medium text-gray-800 mb-3 flex items-center">
                                <MessageCircle className="w-4 h-4 mr-2" />
                                Comments ({comments.filter((c) => c.questionId === question.id).length})
                              </h4>
                              <div className="space-y-2">
                                {comments
                                  .filter((c) => c.questionId === question.id)
                                  .map((comment) => (
                                    <div
                                      key={comment.id}
                                      className={`p-3 rounded-lg border ${
                                        comment.resolved ? "bg-gray-50 border-gray-200" : "bg-white border-gray-300"
                                      }`}
                                    >
                                      <div className="flex items-start space-x-2">
                                        <Avatar className="w-6 h-6">
                                          <AvatarFallback className="bg-emerald-600 text-white text-xs">
                                            {comment.author.avatar}
                                          </AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1">
                                          <div className="flex items-center space-x-2 mb-1">
                                            <span className="text-sm font-medium text-gray-900">
                                              {comment.author.name}
                                            </span>
                                            <span className="text-xs text-gray-500">
                                              {comment.timestamp.toLocaleTimeString()}
                                            </span>
                                            {comment.resolved && (
                                              <Badge variant="outline" className="text-xs text-green-600">
                                                Resolved
                                              </Badge>
                                            )}
                                          </div>
                                          <p className="text-sm text-gray-700">{comment.text}</p>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="settings" className="space-y-6">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>Quiz Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="timeLimit">Time Limit (minutes)</Label>
                          <Input
                            id="timeLimit"
                            type="number"
                            min="1"
                            value={quiz.timeLimit}
                            onChange={(e) => setQuiz({ ...quiz, timeLimit: Number.parseInt(e.target.value) || 30 })}
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label>Public Quiz</Label>
                            <p className="text-sm text-gray-600">Allow anyone to take this quiz</p>
                          </div>
                          <Switch
                            checked={quiz.isPublic}
                            onChange={(checked) => setQuiz({ ...quiz, isPublic: checked })}
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label>Allow Retakes</Label>
                            <p className="text-sm text-gray-600">Students can retake the quiz</p>
                          </div>
                          <Switch
                            checked={quiz.allowRetakes}
                            onChange={(checked) => setQuiz({ ...quiz, allowRetakes: checked })}
                          />
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label>Show Correct Answers</Label>
                            <p className="text-sm text-gray-600">Show answers after completion</p>
                          </div>
                          <Switch
                            checked={quiz.showCorrectAnswers}
                            onChange={(checked) => setQuiz({ ...quiz, showCorrectAnswers: checked })}
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label>Randomize Questions</Label>
                            <p className="text-sm text-gray-600">Show questions in random order</p>
                          </div>
                          <Switch
                            checked={quiz.randomizeQuestions}
                            onChange={(checked) => setQuiz({ ...quiz, randomizeQuestions: checked })}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Collaboration Sidebar */}
      <CollaborationSidebar />
    </div>
  )
}
